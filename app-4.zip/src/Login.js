import React from 'react';
import logo from './logo.svg';
import './App.css';

class Login extends React.Component {

  constructor(){
    super()

    this.state = {
        email: "",
        password: ""
    }

    this.formSubmission = this.formSubmission.bind(this)
  }

  submitEmail(event){
    this.setState({
        email: event.target.value
    })
  }

  submitPassword(event){
    this.setState({
        password: event.target.value
    })
  }

  formSubmission(event){
    alert(`Username: ${this.state.email} Password:${this.state.password} `)
  }

  render(){
  return (
    <div>
        <label>Email</label>
      <input type="text" value={this.state.email} onChange={(e) => this.submitEmail(e)}/>
      <label>Password</label>
      <input type="password" value={this.state.password}  onChange={(e) => this.submitPassword(e)}/>
      <button onClick={this.formSubmission}>Submit</button>

    </div>
  );
  }
}

export default Login;
