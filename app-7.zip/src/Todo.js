import React from 'react';
import logo from './logo.svg';
import './App.css';

class Todo extends React.Component {
  constructor(){
    super()

}
 

  render(){
      
  return (
    <div>
      <p>{this.props.data}</p>
    </div>
  );
}

}

export default Todo;
