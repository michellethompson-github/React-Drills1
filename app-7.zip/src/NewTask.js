import React from 'react';
import logo from './logo.svg';
import './App.css';

class NewTask extends React.Component {
  constructor(){
    super()
  
    this.state = {
        input:""
    };
    this.changeHandler = this.changeHandler.bind(this)
}
    changeHandler(e){
        this.setState({
            input: e.target.value
    })
    }

    AddData(){
        this.props.add(this.state.input)
        this.setState({input: ""})
    }

  render(){

  return (
    <div>
        <input type="text" value={this.state.input} onChange={this.changeHandler}/>
        <button onClick= {()=> this.AddData()}>Add Item</button>
    </div>
  );
}

}

export default NewTask;
