import React from 'react';
import logo from './logo.svg';
import './App.css';
import Todo from './Todo'

class List extends React.Component {
  constructor(){
    super()

}
 

  render(){
      let result = this.props.tasks.map((item, index) => <Todo data={item}/> )
  return (
    <div>
       {result}
    </div>
  );
}

}

export default List;
