import React from 'react';
import logo from './logo.svg';
import './App.css';
import Image from './Image'
class App extends React.Component {

  constructor(){
    super();
  }

  render(){
//props can be used for passing data from parent to child
  return (
    // https://via.placeholder.com/150/0000FF/808080%20?Text=Digital.com%20C/O%20https://placeholder.com/
    <div className="App">
      <Image url={"https://via.placeholder.com/150/0000FF/808080%20?Text=Digital.com%20C/O%20https://placeholder.com/"}/>
    </div>
  );
}
}

export default App;
