import React from 'react'

class Image extends React.Component {
    constructor(props){
        super(props)
    }

    render(){
        return (
            <div>
                <h1>Hello</h1>
                <img src={this.props.url}/>
            </div>
        )
    }
}

export default Image