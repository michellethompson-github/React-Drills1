import React from 'react';
import logo from './logo.svg';
import './App.css';
import Todo from './Todo'

class App extends React.Component {
    constructor(){
      super()

      this.state = {
        list: [], //items list initially empty
        input: "" //Input Initially Empty
      }
      this.addTask = this.addTask.bind(this)
    }

    changeTextHandler(e){ //function called whenever text changes
      this.setState({
        input: e.target.value //Input Field Value getting stored in state
      })
    }

    addTask(e){ //function called on form submit/add item
      this.setState({
        list: [...this.state.list, this.state.input ],
        input: ""
      })
      
    }
  
  render(){
    let output = this.state.list.map((item, index) => {
      return <Todo item={item}/>
     })
  return (
    <div className="App">
     
      <h1>Our To-do List</h1>
      <h4>Items List</h4>

      {/* Displaying Data */}
      {output}

      {/* Our Input Field */}
      <input type="text" value={this.state.input} onChange={(e)=> this.changeTextHandler(e)}/>
     
        {/* Our Add Item Button */}
      <button onClick={this.addTask}>Add Item</button>
    </div>
  );
}
}

export default App;
