import React from 'react'
class Todo extends React.Component {
    constructor(props){
      super(props)
    }

    render(){
        return (
            <p>{this.props.item}</p>
        )
    }
}

export default Todo