import React, { Component } from "react";
import logo from "./logo.svg";
import "./App.css";

class App extends Component {
  constructor() { //All the states go inside constructor
    super();

      this.state = {
        filterString: "",
        foods: ["Chicken", "Pizza", "Chocolate", "Burger", "Chicken Manchurian", "Zinger Burder"]

      }

      this.changeHandler = this.changeHandler.bind(this)
  
  }

  changeHandler(e){
    this.setState({
      filterString: e.target.value //e.target.value receives the data from the input field
    })
  }

  render(){

      let our_data = 
        this.state.foods
        .filter((items, index)=> {
          return items.includes(this.state.filterString)
        })
        .map((item, index)=> {
          return <h2 key={index}>{item}</h2>
        })
      

    return (
      <div className="App">
        <input type="text" value={this.state.filterString} onChange={this.changeHandler}/>
        {our_data}
      </div>
    )
  }
}

export default App;